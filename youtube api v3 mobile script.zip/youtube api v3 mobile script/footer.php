
<div class="rdx"><img alt="" src="http://whatsapp8.com/Funny%20Prank%20Video/home.png"> <a style="font-weight: bold;"
href="http://whatsapp8.com">Home</a></div>
<div class="down">WhatsApp8.Com 2014
</div><center><img src='http://c.wen.ru/2648507.wbmp?' alt=''></a></center>
</body>
</html>